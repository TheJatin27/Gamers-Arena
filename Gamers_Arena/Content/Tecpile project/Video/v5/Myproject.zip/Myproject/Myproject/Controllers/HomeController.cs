﻿using Myproject.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Myproject.Controllers
{
    public class HomeController : Controller
    {
        SqlConnection connection = new SqlConnection("Data Source=AMARTABHAI\\SQLEXPRESS;Initial Catalog=LMS;Integrated Security=True");
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Aboutus()
        {
            return View();
        }
        public ActionResult contact()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Contact(string name, string email, long mobile, string message)
        {
            DBManager dm=new DBManager();
            int x=dm.ExecuteInsertDelete("insert into tbl_contact values('"+name+"',"+mobile+",'"+email+"','"+message+"','"+DateTime.Now+"')");
            if (x > 0)
                Response.Write("<script>alert('Thanks for contacting with us...');</script>");
            else
                Response.Write("<script>alert('Data not saved...');</script>");
     
            return View();
        }
        public ActionResult SignUp()
        {
            return View();
        }
        public ActionResult Admin()
        {
            return View();
        }
        [HttpPost]
        public ViewResult Admin(string UserName,long password)
        {
            string commond = "insert into Admin values('"+UserName+"',"+password+")";
               SqlCommand cmd = new SqlCommand(commond,connection);
            connection.Open();
            cmd.ExecuteNonQuery();
            connection.Close();
            return View();
        }

        public ActionResult  login()
        {
            return View();
        }
        [HttpPost]
        public ViewResult login(string email,long password)
        {
            string command ="insert into student values('"+email+"',"+password+")";
            SqlCommand cmd = new SqlCommand(command, connection);
            connection.Open();
            cmd.ExecuteNonQuery();    
            return View();
        }


        public ActionResult feedback()
        {
          
            return View();
        }

    }
}