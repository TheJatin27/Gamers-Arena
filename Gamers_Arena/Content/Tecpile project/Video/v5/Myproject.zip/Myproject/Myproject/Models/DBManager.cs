﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
namespace Myproject.Models
{
    public class DBManager
    {
        SqlConnection connection= new SqlConnection("Data Source=AMARTABHAI\\SQLEXPRESS;Initial Catalog=LMS;Integrated Security=True");
        public int  ExecuteInsertDelete(string query)
        {
            SqlCommand command = new SqlCommand(query, connection);
            connection.Open();
           int result= command.ExecuteNonQuery();
            connection.Close();
            return result;
        }
       public DataTable ExecuteSelect(string query)
        {
            SqlDataAdapter adapter = new SqlDataAdapter(query,connection); 
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            return dt;
        }
    }
}